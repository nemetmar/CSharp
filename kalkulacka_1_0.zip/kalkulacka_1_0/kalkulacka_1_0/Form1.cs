﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DragonCalculator
{
    public partial class Form1 : Form
    {
        private Kalkulacka kalkulacka;
        private bool jePrvniCislo = true;
        private bool zadanaOperace = false;
        private bool operaceProvedena = false;
        private Operator aktualniOperace;
        
        public Form1()
        {
            InitializeComponent();
            kalkulacka = new Kalkulacka();
            display.Text = "0";
        }


        private void button0_Click(object sender, EventArgs e)
        {
            NastavCislo("0");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NastavCislo("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NastavCislo("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            NastavCislo("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            NastavCislo("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            NastavCislo("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            NastavCislo("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            NastavCislo("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            NastavCislo("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            NastavCislo("9");
        }

        private void buttonDec_Click(object sender, EventArgs e)
        {
            if (!display.Text.Contains(","))
            {
                NastavCislo(",");
            }
        }

        private void buttonEquals_Click(object sender, EventArgs e)
        {
            ProvedOperaci();
            jePrvniCislo = true;
            zadanaOperace = true;
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            VyhodnotOperaci(Operator.Scitani);               
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            VyhodnotOperaci(Operator.Odcitani);
        }

        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            VyhodnotOperaci(Operator.Nasobeni);
        }

        private void buttonDivide_Click(object sender, EventArgs e)
        {
            VyhodnotOperaci(Operator.Deleni);
        }

        private void buttonPow_Click(object sender, EventArgs e)
        {
            VyhodnotOperaci(Operator.Mocneni);
        }

        private void buttonSign_Click(object sender, EventArgs e)
        {
            double cislo = double.Parse(display.Text);
            cislo *= -1;
            display.Text = cislo.ToString();
            if (jePrvniCislo)
            {
                kalkulacka.vysledek = cislo;
            }
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            display.Text = "0";
            jePrvniCislo = true;
            kalkulacka.vysledek = 0;
        }

        private void NastavCislo(string cislo)
        {
            operaceProvedena = false;
            if (display.Text == "0" && cislo != ",")
            {
                display.Text = cislo;
                zadanaOperace = false; //tohle reseni se mi nelibi
            }
            else if (zadanaOperace)
            {
                display.Text = cislo;
                zadanaOperace = false;
            }
            else
            {
                display.Text += cislo;
            }
        }

        private void VyhodnotOperaci(Operator operace)
        {
            if (jePrvniCislo)
            {
                kalkulacka.vysledek = double.Parse(display.Text);
                jePrvniCislo = false;
                operaceProvedena = true;
            }
            else 
            {
                ProvedOperaci();
            }
            aktualniOperace = operace;
            zadanaOperace = true;
        }

        private void ProvedOperaci()
        {
            if (!jePrvniCislo && !operaceProvedena)
            {
                double dalsiCislo = double.Parse(display.Text);
                kalkulacka.Vypocet(aktualniOperace, dalsiCislo);
                display.Text = kalkulacka.vysledek.ToString();
                operaceProvedena = true;
            }
            
        }
    }

    class Kalkulacka
    {
        public double vysledek;

        public Kalkulacka()
        {

        }

        private void Scitani(double a)
        {
            this.vysledek += a;
        }

        private void Odcitani(double a)
        {
            this.vysledek -= a;
        }

        private void Nasobeni(double a)
        {
            this.vysledek *= a;
        }

        private void Deleni(double a)
        {
            this.vysledek /= a;
        }

        private void Mocneni(double a)
        {
            double x = 1;

            if (a < 0 || a > 0)
            {
                double b = Math.Abs(a);
                for (int i = 1; i <= b; i++)
                {

                    x *= this.vysledek;
                }
            }
            if (a < 0)
            {
                x = 1 / x;
            }

            this.vysledek = x;
        }

        public void Vypocet(Operator operace, double a)
        {
            switch (operace)
            {
                case Operator.Scitani: Scitani(a); break;
                case Operator.Odcitani: Odcitani(a); break;
                case Operator.Nasobeni: Nasobeni(a); break;
                case Operator.Deleni: Deleni(a); break;
                case Operator.Mocneni: Mocneni(a); break;
            }
        }
    }

    enum Operator
    {
        Scitani,
        Odcitani,
        Nasobeni,
        Deleni,
        Mocneni
    }
}
