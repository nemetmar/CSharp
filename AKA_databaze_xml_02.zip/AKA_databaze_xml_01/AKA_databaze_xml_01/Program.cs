﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AKA_databaze_xml_01
{
    class Program
    {
        static void Main(string[] args)
        {           
            HrDatabase db = new HrDatabase();

            try
            {
                db.ReadEmployeesFromXml();
                db.GetEmployeesContent();
                DatabaseMenu.ShowMainOptions(db);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }


            Console.WriteLine("Bye.");
            Console.ReadKey();
        }
    }
}
