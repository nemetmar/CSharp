﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace AKA_databaze_xml_01
{
    class HrDatabase
    {
        public List<Employee> Employees = new List<Employee>();
        public int nextId;

        public void GetEmployeesContent()
        {
            if (Employees.Count != 0)
            {
                WriteEmployeesToConsole("Current DB content:", Employees);
            }
            else
            {
                Console.WriteLine("DB is empty, start with adding employees first.");
            }
        }

        public void AddEmployee()
        {
            Employee employee = GetEmployeeFromUser();
            Employees.Add(employee);
            employee.Id = nextId;
            nextId++;
            WriteDbToFiles();
            Console.WriteLine("The employee {0} was added successfully.", employee.Name);
        }

        public void ImportEmployees()
        {
            List<Employee> newEmployees = DbIOMethods.ReadEmployeesFromCsv(this);
            if(newEmployees != null)
            {
                Employees.AddRange(newEmployees);
                WriteDbToFiles();
                Console.WriteLine("Employees from .csv file were added successfully.");
            }
            else
            {
                Console.WriteLine("No employees could be read from .csv file, therefore no employees were added.");
            }
        }

        public void SearchAndDeleteEmployees()
        {
            List<Employee> EmployeesToDelete = SearchEmployees(DatabaseMenu.ShowAndReturnSearchOptions(), true);
            if (EmployeesToDelete != null)
            {
                DeleteEmployees(EmployeesToDelete);
            }
        }

        public void DeleteEmployees(List<Employee> EmployeesToDelete)
        {
            if (DatabaseMenu.DeleteConfirmation())
            {
                for (int i = 0; i < EmployeesToDelete.Count; i++)
                {

                    for (int j = 0; j < Employees.Count; j++)
                    {
                        if (EmployeesToDelete[i].Equals(Employees[j]))
                        {
                            Employees.RemoveAt(j);
                            break;
                        }
                    }
                }
                DeleteEmployeesFromFiles();
                Console.WriteLine("Employees were removed successfully.");
            }
            else
            {
                Console.WriteLine("Ok, nothing has changed in the DB.");
            }
        }

        private void DeleteEmployeesFromFiles()
        {
            if (Employees.Count == 0)
            {
                DbIOMethods.DeleteAllFiles();
            }
            else
            {
                WriteDbToFiles();
            }
        }

        public void SearchAndEditEmployee()
        {
            List<Employee> EmployeeToEdit = SearchEmployees("id", true);
            if (EmployeeToEdit != null)
            {
                EditEmployee(EmployeeToEdit[0]);
            }
        }

        public void EditEmployee(Employee employee)
        {
            DatabaseMenu.ShowEditEmployeeOptions(this, employee);
            WriteDbToFiles();
        }

        public void ReadEmployeesFromXml()
        {
            if (DbIOMethods.XmlExists())
            {
                Employees = DbIOMethods.XmlDeserialize();
                nextId = Employees.Max(e => e.Id) + 1;
            }
            else
            {
                nextId = 1;
            }
        }

        private void WriteDbToFiles()
        {
            DbIOMethods.XmlSerialize(Employees);
            DbIOMethods.AddToCsv(Employees);
        }

        public List<Employee> SearchEmployees(string method, bool isDirectDeleteOrEdit = false)
        {
            if (Employees.Count != 0)
            {
                List<Employee> ListOfResults = new List<Employee>();
                switch (method)
                {
                    case "name":
                        ListOfResults = SearchByName();
                        break;
                    case "ageRange":
                        ListOfResults = SearchByAgeRange();
                        break;
                    case "id":
                        ListOfResults = SearchById();
                        break;
                    default:
                        return null;
                }

                if (ListOfResults.Count != 0)
                {
                    WriteEmployeesToConsole("Found employees:", ListOfResults);
                    if (ListOfResults.Count == 1 && !isDirectDeleteOrEdit)
                    {
                        DatabaseMenu.ShowEmployeeOptions(this, ListOfResults[0]);
                        return null;
                    }
                    return ListOfResults;
                }

                Console.WriteLine("No such employees found.");
                return null;
            }
            Console.WriteLine("DB is empty, start with adding employees first.");
            return null;
        }

        private List<Employee> SearchByName()
        {
            string keyword = UserInput.ReadString("Enter a keyword to search in employees' names: ");
            keyword = keyword.ToLower();
            List<Employee> ListOfResults = new List<Employee>();
            foreach (var item in Employees)
            {
                if (item.Name.ToLower().Contains(keyword))
                {
                    ListOfResults.Add(item);
                }
            }
            return ListOfResults;
        }

        private List<Employee> SearchByAgeRange()
        {
            int from = UserInput.ReadLimitedInt("Enter age minimum: ", Employee.MinAge, Employee.MaxAge);
            int to = UserInput.ReadLimitedInt("Enter age maximum: ", from, Employee.MaxAge);
            var query = Employees.Where(e => e.Age >= from).Where(e => e.Age <= to).ToList();
            return query;
        }

        private List<Employee> SearchById()
        {
            int id = UserInput.ReadInt("Enter employee's id: ");
            var query = Employees.Where(e => e.Id == id).ToList();
            return query;
        }

        private Employee GetEmployeeFromUser()
        {
            Employee employee = new Employee();
            Console.WriteLine("Please, fill in the employee's data.");
            employee.Name = UserInput.ReadString("Name: ");
            employee.Position = UserInput.ReadString("Position: ");
            //employee.TypeOfContract = UserInput.ReadLimitedString("Type of contract: ", new string[] { "Contract", "Parttime", "Fulltime"});
            employee.Type = UserInput.ReadTypeOfContract("Type of contract: ");
            employee.Age = UserInput.ReadLimitedInt("Age: ", Employee.MinAge, Employee.MaxAge);
            employee.HourRate = UserInput.ReadLimitedInt("Rate (CZK/h): ", Employee.MinHourRate, Employee.MaxHourRate);

            return employee;
        }


        public void WriteEmployeesToConsole(string message, List<Employee> ListOfEmployees)
        {
            Console.WriteLine("\n" + message);
            Console.WriteLine("Id".PadRight(5) + "Name:".PadRight(20) + "Position:".PadRight(20) + "Contract type:".PadRight(15) + "Age:".PadLeft(6) + "Rate(CZK/h):".PadLeft(15));
            foreach (var item in ListOfEmployees)
            {
                Console.WriteLine(item.Id.ToString().PadRight(5) + item.Name.PadRight(20) + item.Position.PadRight(20) + item.Type.ToString().PadRight(15) + item.Age.ToString().PadLeft(6) + item.HourRate.ToString().PadLeft(15));
            }
        }
    }
}
