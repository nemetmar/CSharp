﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace AKA_databaze_xml_01
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }

        //public string TypeOfContract { get; set; }     
        public TypeOfContract Type { get; set; }
        public int Age { get; set; }
        public int HourRate { get; set; }

        public const int MinAge = 18;
        public const int MaxAge = 90;
        public const int MinHourRate = 200;
        public const int MaxHourRate = 5000;

        public override string ToString()
        {
            return string.Join(";", Name, Position, Type, Age, HourRate);
        }

        
    }
}
