﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AKA_databaze_xml_01
{
    static class UserInput
    {
        
        public static int ReadLimitedInt(string message, int minLimit, int maxLimit)
        {
            int number = ReadInt(message);
            while(number < minLimit || number > maxLimit)
            {
                if (number > maxLimit)
                {
                    number = ReadInt("Cannot accept numbers above " + maxLimit + ".\n" + message);
                }
                else
                {
                    number = ReadInt("Cannot accept numbers below " + minLimit + ".\n" + message);
                }
            }
            return number;
        }

        public static int ReadInt(string message)
        {
            bool isNumber = false;
            int number = 0;
            while (!isNumber)
            {
                Console.Write(message);
                string input = Console.ReadLine();
                isNumber = int.TryParse(input, out number);
            }
            return number;
        }

        public static string ReadLimitedString(string message, string[] acceptableStrings)
        {
            string input = ReadString(message);
            while(!acceptableStrings.Contains(input))
            {
                input = ReadString("Can accept only these values: " + string.Join(" ", acceptableStrings) + "\n");
            }
            return input;
        }

        public static TypeOfContract ReadTypeOfContract(string message)
        {
            bool isTypeOfContract = false;
            TypeOfContract type = TypeOfContract.Contract;
            string[] acceptableTypes = Enum.GetNames(typeof(TypeOfContract));

            while(!isTypeOfContract)
            {
                string input = ReadString(message);
                isTypeOfContract = Enum.TryParse(input, out type);
                if (!isTypeOfContract)
                {
                    Console.WriteLine("Can accept only these values: " + string.Join(" ", acceptableTypes));
                }
            }
            return type;
        }

        public static string ReadString(string message)
        {
            string input = "";
            while (input == "")
            {
                Console.Write(message);
                input = Console.ReadLine();
                input = input.Trim();
            }

            return input;
        }
    }
}
