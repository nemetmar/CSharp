﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AKA_databaze_xml_01
{
    public enum TypeOfContract
    {
        Contract,
        Parttime,
        Fulltime
    }
}
