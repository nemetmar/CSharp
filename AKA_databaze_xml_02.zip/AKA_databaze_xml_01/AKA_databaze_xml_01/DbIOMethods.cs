﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace AKA_databaze_xml_01
{
    static class DbIOMethods
    {
        private const string XmlFilePath = "db.xml";
        private const string CsvFilePath = "db.csv";

        public static bool XmlExists()
        {
            return File.Exists(XmlFilePath);
        }

        public static void XmlSerialize(List<Employee> employees)
        {
            XmlSerializer xml = new XmlSerializer(employees.GetType());

            using (StreamWriter sw = new StreamWriter(XmlFilePath))
            {
                xml.Serialize(sw, employees);
            }
        }

        public static List<Employee> XmlDeserialize()
        {
            List<Employee> employees = new List<Employee>();

            XmlSerializer xml = new XmlSerializer(employees.GetType());

            using (StreamReader sr = new StreamReader(XmlFilePath))
            {
                employees = (List<Employee>)xml.Deserialize(sr);
            }

            return employees;
        }

        public static void AddToCsv(List<Employee> employees)
        {
            using (StreamWriter sw = new StreamWriter(CsvFilePath))
            {
                foreach (var employee in employees)
                {
                    sw.WriteLine(employee.ToString());
                }
                sw.Flush();
            }
        }

        public static List<Employee> ReadEmployeesFromCsv(HrDatabase db)
        {
            string csvFromUserPath = UserInput.ReadString("Enter full path of your .csv file: ");
            if (File.Exists(csvFromUserPath))
            {
                try { 
                    List<Employee> newEmployees = new List<Employee>();
                    using (StreamReader sr = new StreamReader(csvFromUserPath))
                    {
                        string s;
                        while ((s = sr.ReadLine()) != null)
                        {
                            string[] line = s.Split(';');
                            Employee e = new Employee();
                            e.Id = db.nextId;
                            db.nextId++;
                            e.Name = line[0];
                            e.Position = line[1];
                            e.Type = (TypeOfContract)Enum.Parse(typeof(TypeOfContract), line[2]);
                            e.Age = int.Parse(line[3]);
                            CheckRange(e.Age, Employee.MinAge, Employee.MaxAge, "Age is not in the allowed range.");
                            e.HourRate = int.Parse(line[4]);
                            CheckRange(e.HourRate, Employee.MinHourRate, Employee.MaxHourRate, "Hour rate is not in the allowed range.");

                            newEmployees.Add(e);
                        }
                    }
                    return newEmployees;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Something went wrong. Check the .csv file format.\nOriginal message: " + e);
                    return null;
                }
            }
            Console.WriteLine("File at this path does not exist.");
            return null;
        }

        private static void CheckRange(int number, int min, int max, string message)
        {
            if(number < min || number > max)
            {
                throw new Exception(message);
            }
        }

        public static void DeleteAllFiles()
        {
            File.Delete(XmlFilePath);
            File.Delete(CsvFilePath);
        }
    }
}
