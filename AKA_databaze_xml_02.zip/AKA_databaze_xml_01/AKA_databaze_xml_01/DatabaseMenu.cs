﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AKA_databaze_xml_01
{
    static class DatabaseMenu
    {
        public static void ShowMainOptions(HrDatabase db)
        {
            string[] menu = { "0", "1", "2", "3", "4", "5", "6" };
            string input = menu[0];
            while (menu.Contains(input) && input != "6")
            {
                input = UserInput.ReadLimitedString("\nPress a key to:\n0: show current DB contents\n1: add an employee to DB\n2: import employees from .csv\n3: search employees\n4: delete employees\n5: edit an employee\n6: end program\n", menu);
                switch (input)
                {
                    case "0":
                        db.GetEmployeesContent();
                        break;
                    case "1":
                        db.AddEmployee();
                        break;
                    case "2":
                        db.ImportEmployees();
                        break;
                    case "3":
                        db.SearchEmployees(ShowAndReturnSearchOptions());
                        break;
                    case "4":
                        db.SearchAndDeleteEmployees();
                        break;
                    case "5":
                        db.SearchAndEditEmployee();
                        break;
                    default:
                        break;
                }
            }
        }

        public static string ShowAndReturnSearchOptions()
        {
            string[] values = { "0", "1", "2", "3" };

            string value = UserInput.ReadLimitedString("\nselect search:\n1: search by name\n2: search by age range\n3: search by id\n0: exit\n", values);
            switch (value)
            {
                case "1":
                    return "name";
                case "2":
                    return "ageRange";
                case "3":
                    return "id";
                default:
                    return null;
            }

        }

        public static void ShowEmployeeOptions(HrDatabase db, Employee e)
        {
            string[] values = { "0", "1", "2" };
            string value = UserInput.ReadLimitedString("\nselect action:\n1: edit employee\n2: delete employee\n0: exit\n", values);
                switch (value)
                {
                    case "1":
                        db.EditEmployee(e);
                        break;
                    case "2":
                        db.DeleteEmployees(new List<Employee> { e });
                        break;
                    default:
                        break;
                }
        }

        public static void ShowEditEmployeeOptions(HrDatabase db, Employee e)
        {
            string[] values = { "0", "1", "2", "3", "4", "5" };
            string value = values[1];
            while (values.Contains(value) && value != "0")
            {
                value = UserInput.ReadLimitedString("\nselect value to edit:\n1: name\n2: position\n3: type of contract\n4: age\n5: rate\n0: save and/or exit\n", values);
                switch (value)
                {
                    case "1":
                        e.Name = UserInput.ReadString("Current name: " + e.Name + "\nNew name: ");
                        break;
                    case "2":
                        e.Position = UserInput.ReadString("Current position: " + e.Position + "\nNew position: ");
                        break;
                    case "3":
                        e.Type = UserInput.ReadTypeOfContract("Current type of contract: " + e.Type.ToString() + "\nNew type of contract: ");
                        break;
                    case "4":
                        e.Age = UserInput.ReadLimitedInt("Current age: " + e.Age.ToString() + "\nNew age: ", Employee.MinAge, Employee.MaxAge);
                        break;
                    case "5":
                        e.HourRate = UserInput.ReadLimitedInt("Current rate: " + e.HourRate.ToString() + "\nNew rate: ", Employee.MinHourRate, Employee.MaxHourRate);
                        break;
                    default:
                        break;
                }
                if(value != "0")
                {
                    db.WriteEmployeesToConsole("Employee id." + e.Id + " was edited successfully:", new List<Employee> { e });
                }
            }
        }

        public static bool DeleteConfirmation()
        {
            string answer = UserInput.ReadLimitedString("\nAre you sure to delete this? (y/n)", new string[] { "y", "n" });
            if (answer == "y")
            {
                return true;
            }
            return false;
        }
    }
}
